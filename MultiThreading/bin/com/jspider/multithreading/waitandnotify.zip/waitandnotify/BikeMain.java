package com.jspider.multithreading.waitandnotify;


public class BikeMain {
	public static void main(String[] args) {
		
		Bike bike=new Bike();
		Customer customer=new Customer(bike);
		Honda honda=new Honda(bike);
		
		customer.start();
		honda.start();
		
	}
}
